import React from 'react';
import LabelWithInput from './input_group1.js';

function App() {
  
  return (
    <div>
      <LabelWithInput/>
    </div>
  );
}

export default App;
